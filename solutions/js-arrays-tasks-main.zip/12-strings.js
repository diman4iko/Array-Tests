const sentence = 'When you play the game of thrones, you win or you die';
const stopWords = ['play', 'die'];
const censoredSentence = makeCensored(sentence, stopWords);
